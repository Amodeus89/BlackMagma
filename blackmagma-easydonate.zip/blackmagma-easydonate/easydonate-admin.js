document.addEventListener('DOMContentLoaded', () => {
// JS логика для интерфейса администратора EasyDonate
});
