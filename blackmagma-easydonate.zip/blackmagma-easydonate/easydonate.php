<?php
/**
 * Plugin Name: EasyDonate Integration
 * Description: Интеграция с EasyDonate API для отображения товаров, топ-донатеров и прогресса сбора на сайте WordPress. Поддержка нескольких магазинов.
 * Version: 1.8
 * Author: BlackMagma
 */
// Содержимое опущено для краткости
